import slack
import os
from pathlib import Path
from dotenv import load_dotenv

env_path = Path('.') / '.env'
load_dotenv(dotenv_path=env_path)

client = slack.WebClient(token=os.environ['SLACK_TOKEN'])

def get_channel_messages(channel_id):
    response = client.conversations_history(channel=channel_id)
    messages = response.get('messages', [])
    ordered_messages = sorted(messages, key=lambda x: x.get('ts', 0))
    formatted_messages = [{"user": msg.get('user'), "text": msg.get('text')} for msg in ordered_messages]
    return formatted_messages

def process_messages_with_ai(messages):
    # Placeholder for AI processing
    ai_response = []
    return ai_response

def send_dms(responses):
    for response in responses:
        user_id = response['id']
        text = response['text']
        client.chat_postMessage(channel=user_id, text=text)

channel_id = "CXXXXXX"  
messages = get_channel_messages(channel_id)
ai_responses = process_messages_with_ai(messages)
send_dms(ai_responses)
